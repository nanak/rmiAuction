Die BidningNamen der Server stehen in registry.properties!
Es sind diese dort anzuf�hren, sonst wird eine Ausgabe erscheinen,
de einen auf den Missstand hinweist.