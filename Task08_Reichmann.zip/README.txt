Die BidningNamen der Server stehen in registry.properties!
Es sind diese dort anzuf�hren, sonst wird eine Ausgabe erscheinen,
die einen auf den Missstand hinweist.
Die Files werden vom BuildXML in das RootVerzeichnis gespeichert. Dort geh�ren sie hin